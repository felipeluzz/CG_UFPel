// Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <iostream>
#include <algorithm>
#include <string>
#include <set>
#include <iterator>
#include <stack>

//Inclui classes novas
#include <mesh.hpp>

// Include GLEW
#include <GL/glew.h>

// Include GLFW
#include <glfw3.h>
GLFWwindow* g_pWindow;
unsigned int g_nWidth = 1024, g_nHeight = 768;

// Include AntTweakBar
#include <AntTweakBar.h>
TwBar *g_pToolBar;

// Include GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
using namespace glm;

#include <shader.hpp>
#include <texture.hpp>
#include <controls.hpp>
#include <objloader.hpp>
#include <vboindexer.hpp>
#include <glerror.hpp>
#include <meshSimplification.hpp>
#include <modelManager.hpp>


void WindowSizeCallBack(GLFWwindow *pWindow, int nWidth, int nHeight) {

	g_nWidth = nWidth;
	g_nHeight = nHeight;
	glViewport(0, 0, g_nWidth, g_nHeight);
	TwWindowSize(g_nWidth, g_nHeight);
}

int main(void)
{
	int nUseMouse = 0;

	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Open a window and create its OpenGL context
	g_pWindow = glfwCreateWindow(g_nWidth, g_nHeight, "CG UFPel", NULL, NULL);
	if (g_pWindow == NULL){
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(g_pWindow);

	// Initialize GLEW
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		return -1;
	}

	check_gl_error();//OpenGL error from GLEW

	// Initialize the GUI
	TwInit(TW_OPENGL_CORE, NULL);
	TwWindowSize(g_nWidth, g_nHeight);

	// Set GLFW event callbacks. I removed glfwSetWindowSizeCallback for conciseness
	glfwSetMouseButtonCallback(g_pWindow, (GLFWmousebuttonfun)TwEventMouseButtonGLFW); // - Directly redirect GLFW mouse button events to AntTweakBar
	glfwSetCursorPosCallback(g_pWindow, (GLFWcursorposfun)TwEventMousePosGLFW);          // - Directly redirect GLFW mouse position events to AntTweakBar
	glfwSetScrollCallback(g_pWindow, (GLFWscrollfun)TwEventMouseWheelGLFW);    // - Directly redirect GLFW mouse wheel events to AntTweakBar
	glfwSetKeyCallback(g_pWindow, (GLFWkeyfun)TwEventKeyGLFW);                         // - Directly redirect GLFW key events to AntTweakBar
	glfwSetCharCallback(g_pWindow, (GLFWcharfun)TwEventCharGLFW);                      // - Directly redirect GLFW char events to AntTweakBar
	glfwSetWindowSizeCallback(g_pWindow, WindowSizeCallBack);

	//create the toolbar
	g_pToolBar = TwNewBar("CG UFPel ToolBar");
	//Adiciona novo model
	glm::vec3 posicaoModel;
	TwAddVarRW(g_pToolBar, "Model", TW_TYPE_DIR3F, &posicaoModel, "label = 'Novo Model'");
	int meshID = 0;
	TwAddVarRW(g_pToolBar, "MeshID", TW_TYPE_INT8, &meshID, "label = 'MehsID'");


	// Ensure we can capture the escape key being pressed below
	glfwSetInputMode(g_pWindow, GLFW_STICKY_KEYS, GL_TRUE);
	glfwSetCursorPos(g_pWindow, g_nWidth / 2, g_nHeight / 2);

	// Dark blue background
	glClearColor(0.0f, 0.0f, 0.4f, 0.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);
	// Accept fragment if it closer to the camera than the former one
	glDepthFunc(GL_LESS);

	// Cull triangles which normal is not towards the camera
	glEnable(GL_CULL_FACE);

	GLuint VertexArrayID;
	glGenVertexArrays(1, &VertexArrayID);
	glBindVertexArray(VertexArrayID);

	// Create and compile our GLSL program from the shaders
	GLuint programID = LoadShaders("shaders/StandardShading.vertexshader", "shaders/StandardShading.fragmentshader");

	std::vector<std::pair<int, int>> contagemVizinhos;  //Vector onde fica a contagem dos vizinhos
	std::vector<std::set<unsigned short> > vizinhos; //Vector que cont�m os vizinhos dos v�rtices
	std::stack <std::vector<glm::vec3> > verticesRemovidos; //Vetor que armazena os v�rtices removidos
	std::stack <std::vector<unsigned short> > indicesAntigos; //Vetor que armazena os �ndices antigos

	// Get a handle for our "LightPosition" uniform
	glUseProgram(programID);
	GLuint LightID = glGetUniformLocation(programID, "LightPosition_worldspace");

	// For speed computation
	double lastTime = glfwGetTime();
	int nbFrames    = 0;

	int simplificar=0, desfazer = 0, stepS = 0, stepD = 0, MeshN = 0; //Flags para controle das teclas

	std::cout << "Pressione S para simplificar a malha; \n D para desfazer a simplifica��o; \n Q para dar 1 passo de simplifica��o; \n W para desfazer 1 passo de simplifica��o; \n Espa�o para pausar o que estiver fazendo; \n D para Transla��o \n E para Escala \n R para rota��o \n X para ShearX, Y para ShearY, Z para ShearZ \n C para Composta \n O para proje��o \n T para ativar a transforma��o \n B para adicionar uma nova mesh \n N para adicionar um novo model \n";
	std::cout << "\n------C�mera------\n";
	std::cout << "\nColoque a posi��o de uma nova c�mera na barra Transla��o e en�o aperte K para cri�-la";
	std::cout << "\nColoque os valores da transla��o na barra e o tempo de transforma��o e pressione H para coloca-la na fila";
	std::cout << "\nColoque o eixo de rota��o desejado na barra re rota��o, o �ngulo e o tempo da rota��o e pressione J para coloc�-la na fila";
	std::cout << "\nColoque a posi��o do lookAt na barra, o centro da camera e o tempo de transforma��o e pression F para coloca-la na fila";
	std::cout << "\nColoque o ponto que deseja rotacionar em volta na barra Rota��o, o angulo e o tempo da transforma��o e pressione M para coloca-la na fila";
	std::cout << "\nColoque um ponto da curva linear na barra Ponto e o tempo (total) e pressione P para adiciona-lo na fila, insira quantos pontos quiser";
	std::cout << "\nColoque o p0 da B-Spline na barra Ponto e o tempo (total) e pressione L para adiciona-lo a fila, repita at� p3 (n�o mais do que 4 pontos)";
	std::cout << "\nColoque o p0 da B�zier na barra Ponto e o tempo (total) e pressione A para adicion�-lo na fila, repita at� p3 (n�o mais do que 4 pontos)";
	std::cout << "\nPressione G para executar as transforma��es contidas na fila";
	std::cout << "\nOBS: Para as curvas, a fila deve possuir apenas os pontos dela, sem nenhum outro tipo de transforma��o";

	int meshCount = 0;
	modelManager ModelManager(g_pToolBar, programID);
	//Adiciona primeira suzanne
	ModelManager.addMesh("mesh/suzanne.obj");
	glm::vec3 posicao(3.0f, 3.0f, 0.0f);
	ModelManager.addModel(programID, "mesh/uvmap.DDS", posicao, 0);
	
	//Adiciona segunda suzanne
	posicao.x = -3.0f;
	posicao.y = -3.0f;
	ModelManager.addModel(programID, "mesh/uvmap.DDS", posicao, 0);
	//Adiciona ganso
	ModelManager.addMesh("mesh/goose.obj");
	posicao.x = -3.0f;
	posicao.y =  3.0f;
	ModelManager.addModel(programID, "mesh/goose.dds", posicao, 1);
	/*
	//Adiciona cubo
	ModelManager.addMesh("mesh/cube.obj");
	posicao.x = 3.0f;
	posicao.y = -3.0f;
	ModelManager.addModel(programID, "mesh/uvmap.DDS", posicao, 1);
	*/


	do{
        check_gl_error();

		/*if (glfwGetKey(g_pWindow, GLFW_KEY_L) == GLFW_PRESS) //Se o usu�rio pressionar L, muda o para o modo de "linhas"
			glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

		if (glfwGetKey(g_pWindow, GLFW_KEY_P) == GLFW_PRESS) //Se o usu�rio pressionar P, muda o para o modo de "pontos"
			glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);

		if (glfwGetKey(g_pWindow, GLFW_KEY_M) == GLFW_PRESS) //Se o usu�rio pressionar M, muda o para o modo "cheio" (normal)
			glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

		*/
		if (glfwGetKey(g_pWindow, GLFW_KEY_S) == GLFW_PRESS) //Se o usu�rio pressionar S, inicia a simplifica��o da malha
			simplificar = 1;

		if (glfwGetKey(g_pWindow, GLFW_KEY_D) == GLFW_PRESS) //Se o usu�rio pressionar D, desfaz a simplifica��o da malha
			desfazer = 1;

		if (glfwGetKey(g_pWindow, GLFW_KEY_Q) == GLFW_PRESS) //Se o usu�rio pressionar Q, realiza 1 passo de simplifica��o da malha
			stepS = 1;

		if (glfwGetKey(g_pWindow, GLFW_KEY_W) == GLFW_PRESS) //Se o usu�rio pressionar W, realiza 1 passo da opera��o de desfazer a simplifica��o
			stepD = 1;

		if (glfwGetKey(g_pWindow, GLFW_KEY_SPACE) == GLFW_PRESS) { //Se o usu�rio pressionar Espa�o, para o que estiver fazendo
			simplificar = 0;
			desfazer = 0;
			stepS = 0;
			stepD = 0;
		}

		
		//Faz a simplifica��o, contanto que as teclas certas sejam pressionadas, e que ainda seja poss�vel simplificar a malha
		if ((ModelManager.getMesh().at(MeshN).getVertices().size() > 3 && ModelManager.getMesh().at(MeshN).getIndices().size() > 3  && simplificar == 1) || (ModelManager.getMesh().at(MeshN).getVertices().size() > 3 && ModelManager.getMesh().at(MeshN).getIndices().size() > 3 && stepS == 1)) {
			CalculaVizinhos(ModelManager.getMesh().at(MeshN).getVertices(), ModelManager.getMesh().at(MeshN).getIndices(), contagemVizinhos, vizinhos);
			TriangleCollapse(ModelManager.getMesh().at(MeshN).getVertices(), ModelManager.getMesh().at(MeshN).getIndices(), contagemVizinhos, vizinhos, verticesRemovidos, indicesAntigos);
			contagemVizinhos.clear();
			vizinhos.clear();
			stepS = 0;
		}
		else {
			simplificar = 0;
			stepS = 0;
		}

		//Desfaz a simplifica��o, contanto que as teclas certas sejam pressionadas, e que ainda haja algo para desfazer
		if ((desfazer == 1 && verticesRemovidos.size() != 0) || (stepD == 1 && verticesRemovidos.size() != 0)) {
			refazer(verticesRemovidos, indicesAntigos, ModelManager.getMesh().at(MeshN).getIndices(), ModelManager.getMesh().at(MeshN).getVertices());
			stepD = 0;
		}
		else {
			desfazer = 0;
			stepD = 0;
		}

		double currentTime = glfwGetTime();
		if (currentTime - lastTime >= 0.8) {
			if (glfwGetKey(g_pWindow, GLFW_KEY_B)) { //Adiciona mesh
				std::string meshName;
				std::cout << "\nInsira o caminho da nova mesh:\n";
				std::cin >> meshName;
				const char* meshNameC = meshName.c_str();
				meshCount += 1;
				ModelManager.addMesh(meshNameC);
				std::cout << "Conclu�do, o ID desta mesh �: " << meshCount << "\n";
			}

			if (glfwGetKey(g_pWindow, GLFW_KEY_N)) { //Adiciona model
				std::string texture;
				std::cout << "\nInsira o caminho da textura do novo model:\n";
				std::cin >> texture;
				const char* textureC = texture.c_str();
				ModelManager.addModel(programID, textureC, posicaoModel, meshID);
			}
		}


        //use the control key to free the mouse
		if (glfwGetKey(g_pWindow, GLFW_KEY_LEFT_CONTROL) != GLFW_PRESS)
			nUseMouse = 0;
		else
			nUseMouse = 0;

		// Measure speed
		
		nbFrames++;
		if (currentTime - lastTime >= 1.0){ // If last prinf() was more than 1sec ago
			// printf and reset
			//printf("%f ms/frame\n", 1000.0 / double(nbFrames));
			nbFrames  = 0;
			lastTime += 1.0;
		}

		// Clear the screen
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Use our shader
		glUseProgram(programID);

		// Compute the MVP matrix from keyboard and mouse input
		computeMatricesFromInputs(nUseMouse, g_nWidth, g_nHeight);

		ModelManager.draw(g_pWindow, LightID);

	} // Check if the ESC key was pressed or the window was closed
	while (glfwGetKey(g_pWindow, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
	glfwWindowShouldClose(g_pWindow) == 0);

	for(int i = 0; i < ModelManager.getMesh().size(); i++)
		ModelManager.getMesh().at(i).clean();
	glDeleteProgram(programID);

	for (int i = 0; i < ModelManager.getModel().size(); i++)
		ModelManager.getModel().at(i).clean();
	//glDeleteTextures(1, &Texture);
	glDeleteVertexArrays(1, &VertexArrayID);

	// Terminate AntTweakBar and GLFW
	TwTerminate();
	glfwTerminate();

	return 0;
}




